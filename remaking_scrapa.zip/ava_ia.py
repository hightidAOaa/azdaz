import threading, requests, time
from pathlib import Path
import os
zefzegze=open("urls.txt", "w")
zefzegze.close()

import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import concurrent.futures
import random

def scrape_urls():
    headers = {'Accept-Language': 'en',
           'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'}
    while True:
        try:
            # Select a random dork from the list
            dork = random.choice(dorks)

            while True:
                # Select a random SOCKS4 proxy from the list

                # Create a session with the SOCKS4 proxy
                session = requests.Session()
                #session.proxies = {
                #    'http': f'{proxy}',
                #    'https': f'{proxy}'
                #}

                try:
                    # Send a GET request to the search engine with the dork and headers using the SOCKS4 proxy
                    response = session.get(search_engine_url.format(dork), headers=headers)
                    response.raise_for_status()

                    # Parse the HTML response
                    soup = BeautifulSoup(response.text, 'html.parser')

                    # Find all the search result links
                    result_links = soup.find_all('a')

                    # Extract the URLs from the search result links
                    extracted_urls = {link.get('href') for link in result_links}

                    # Filter and clean the URLs
                    filtered_urls = {url for url in extracted_urls if url and url.startswith('http')}

                    # Extract the website domain from the URLs
                    domains = {urlparse(url).netloc for url in filtered_urls}

                    # Filter out the already scraped domains
                    new_domains = [domain for domain in domains if domain not in blacklist]

                    # Add the new domains to the blacklist
                    blacklist.update(new_domains)
                    if len(new_domains)>2:
                        zefzegze=open("urls.txt", "+a")
                        zefzegze.write('\n')
                        zefzegze.write(('\n'.join(new_domains)))
                        zefzegze.close()

                    # Append the new domains to the global URLs list
                    urls.extend(new_domains)

                    # Remove the successful dork from the list

                    break  # Break out of the loop if successful scrape

                except requests.exceptions.RequestException as e:
                    pass

                    # Remove the failed proxy from the list


        except Exception as e:
            print("An error occurred in the thread:", e)

# Define your search engine URL
global search_engine_url
search_engzdine_url = "https://www.google.com/search?q={}"  # Replace with your search engine URL
search_engine_url = "https://www.bing.com/search?q={}"  # Replace with your search engine URL

# Load the dorks from a text file
with open("dorks.txt", "r") as file:
    dorks = ((open('dorks.txt', 'r')).read()).split('\n')

# Define the headers
headers = {'Accept-Language': 'en',
           'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'}

# Number of threads for concurrent scraping

# Load SOCKS4 proxies from a text file
with open("proxat.txt", "r") as file:
    proxies = [line.strip() for line in file]

# Create a set to store the scraped domains
global blacklist
blacklist = set()

# Create a list to store the scraped URLs
global urls
urls = []

# Scrape the URLs using the search engine, dorks, headers, blacklist, and proxies with concurrent threads

for _ in range(6):
    (threading.Thread(target=scrape_urls)).start()
print("Scraped domains have been written to urls.txt.")
for _ in range(1):
    """
    Function to clear the screen every 15 seconds in a separate thread.
    """
    while True:
        for _ in range(1):
            try:
                ornaa=list()
                blaclistaa=list()
                print(str(len(urls))+' links')  # Replace 'clear' with the appropriate command for your operating system
                print(str(len(dorks))+' dorks')
                time.sleep(2)  # Wait for 15 seconds before clearing the screen again
            except Exception as ezfzeg:
                print(ezfzeg)

    # Create a thread and start executing the clear_screen function
# (threading.Thread(target=clear_screen)).start()

